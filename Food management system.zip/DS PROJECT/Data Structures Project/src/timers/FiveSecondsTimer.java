package timers;

import java.util.Timer;
import java.util.TimerTask;


public class FiveSecondsTimer {
    static Timer timer;

    public FiveSecondsTimer(int seconds,int ID) throws InterruptedException {
        timer = new Timer(); 
        timer.schedule(new RemindTask(), seconds*1000);
        Thread.sleep(10000);
        System.out.println("Cust ID: " + ID + "\n ");
	}

    static class RemindTask extends TimerTask {
        public void run() {
            System.out.println("Please collect your Order");
           // timer.cancel(); //Terminate the timer thread
        }
        
    }

   /* public static void main(String args[]) {2
    * 
        new FiveSecondsTimer(5);
        System.out.println("Task scheduled.");
    }*/
}