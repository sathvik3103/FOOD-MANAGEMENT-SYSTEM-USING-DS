package admin;
import java.util.*;

import java.io.*;

public class Admin extends QueueLL{
	protected static Node head;
	protected static Node sorted;
	static Admin List;
	public static class Node 
	{ 
		public int serial; 
		public Node next;
		public String name;
		public int quantity;
		public float price;
		Node(int d,String n,int q,float p) {
			serial = d;
			name=n;
			quantity=q;
			price=p;
			next = null;
		} 
	}
	
	public static void admin() throws IOException {
		System.out.println("Please choose on from the following: ");
		System.out.println("1. Food List Preview 	    	        2.Add to the Food List");
		System.out.println("3.Delete Food from the list		4.View Payments");
		System.out.println("5.Go to Previous Menu 			6.Exit");
		@SuppressWarnings("resource")
		Scanner in=new Scanner(System.in);
		int cha=in.nextInt();
		if(cha==1) { 
			foodlist();
			printList();
			admin();
		}
		else if(cha==2) {
			System.out.print("Enter the serial of the food: ");
			int ser=in.nextInt();
			in.nextLine();
			System.out.print("Enter Name of the food: ");
			String nam;
			nam=in.nextLine();
			System.out.print("Enter the quantity of the food: ");
			int quan=in.nextInt();
			System.out.print("Enter the price of the food: ");
			float pri=in.nextFloat();
			addfood(ser,nam,quan,pri);
			admin();
		}
		else if(cha==3) {
			System.out.println("Enter the serial number of the food you wish to delete: ");
			int s=in.nextInt();
			delfood(s);
			admin();
		}
		else if(cha==4) {
			payments();
			admin();
		}
		else if(cha==5)
			System.out.println("		Previous Menu");
		else if(cha==6)
			System.out.println("		Thank You!   You will automatically redirected to Previous Menu.");
		else {
			System.out.println("Invalid choice");
			admin();
		}
	}
	
	static void insertionSort(Node headref) 
	{ 
		sorted = null; 
		Node current = headref;
		while (current != null) 
		{  
			Node next = current.next;  
			sortedInsert(current);
			current = next; 
		} 
		head = sorted; 
	} 
	
	public static void sortedInsert(Node newnode) 
	{ 
		if (sorted == null || sorted.serial >= newnode.serial) 
		{ 
			newnode.next = sorted; 
			sorted = newnode; 
		} 
		else
		{ 
			Node current = sorted;
			while (current.next != null && current.next.serial < newnode.serial) 
			{ 
				current = current.next; 
			} 
			newnode.next = current.next; 
			current.next = newnode; 
		} 
	} 
	
	public static void foodlist() {
		System.out.println("		Food list");
		System.out.println("The order in which food items are displayed: " + "\n ");
		System.out.println(" Serial" +  "  Name of Food" + "  Quantity"  + "    Price(per quantity" + "\n");
		insertionSort(Admin.head);
	}
	
	public static void addfood(int serno,String namfood,int quanfood,float pricefood) {

		Node new_node=new Node(serno,namfood,quanfood,pricefood);
		if (head == null) 
		{ 
			head = new Node(serno,namfood,quanfood,pricefood); 
			return; 
		} 
		new_node.next = null; 
		Node last = head; 
		while (last.next != null) 
			last = last.next; 
		last.next = new_node; 
		return; 
	}
	
	public static void printList() 
	{ 
		Node tnode = head; 
		while (tnode != null) 
		{ 
			System.out.print(tnode.serial+"  "); 
			System.out.print(tnode.name+"  ");
			System.out.print(tnode.quantity+ "  ");
			System.out.println(tnode.price);
			tnode = tnode.next; 
		}
	}
	
	public static void delfood(int serialno) {
		System.out.println("		Delete Food");
		if (head == null) 
	            return; 
	    Node temp = head;
	    Node temp1=head;
	    int c=getCount();
	    if (temp.serial==serialno) {
	    	head=head.next;
	    	System.out.println("Food item of serial number" + serialno + "deleted successfully! ");
	            return; 
	        } 
	    System.out.println("No of nodes in the list are: " + c);
	    while(temp != null)
		{
			if(temp.next.serial==serialno)
			{
				temp1=temp.next;
				temp.next=temp1.next;
				temp1=null;
				System.out.println("Food item of serial number" + serialno + "deleted successfully! ");
				return;
			}
		temp=temp.next;
		}
	} 
	public static void payments() {
		System.out.println("		Payments");
	}
	
	 public static int getCount() 
	    { 
	        Node temp = head; 
	        int count = 0; 
	        while (temp != null) 
	        { 
	            count++; 
	            temp = temp.next; 
	        } 
	        return count; 
	    } 
	
/*	public static void main(String[] args) throws IOException {
		admin();
	}*/
}