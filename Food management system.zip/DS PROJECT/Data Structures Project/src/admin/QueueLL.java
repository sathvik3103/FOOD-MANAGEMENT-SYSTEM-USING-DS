package admin;


class QNode { 
	int key; 
	QNode next; 
	public QNode(int key) 
	{ 
		this.key = key; 
		this.next = null; 
	} 
} 

class QueueLL{ 
	static QNode front;
	static QNode rear; 

	public QueueLL() 
	{ 
		QueueLL.front = QueueLL.rear = null; 
	} 

	public static void enqueue(int key) 
	{ 

		QNode temp = new QNode(key); 
 
		if (rear == null) { 
			front = rear = temp; 
			return; 
		} 
 
		rear.next = temp; 
		rear = temp; 
	} 
 
	public static void dequeue() 
	{  
		if (front == null) 
			return; 

		@SuppressWarnings("unused")
		QNode temp = front;
		front = front.next;  
		if (front == null) { 
			rear = null; 
		//	System.out.println("Customer Queue is free now!!");
		}
		else
		 System.out.println("Next Customer in Queue : " + QueueLL.front.key);
	} 
} 
