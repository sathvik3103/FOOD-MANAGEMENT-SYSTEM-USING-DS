import java.util.Random;
import java.util.Scanner;
import admin.*;
import timers.FiveSecondsTimer;

import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class Project extends Admin{
	static Scanner inp=new Scanner(System.in);
	public static int n,j,l,custcount=0,custId=0;
	public static int k=custcount;
	public static int a[][]=new int[10][2];
	public static int custID[]=new int[10000];
	public static float totalbill=0;
	public static String custname[][]=new String[1000][1000],totalbillstr;

	public static void customer() throws IOException, InterruptedException {
		System.out.println("You are on the Customer panel!");
		System.out.println("Here is the list of food items to buy!!  \n");
		printList();
		choice_of_customer();
		make_changes();
		int custchoice=inp.nextInt();
		if(custchoice==1)
			proceed();
		else if(custchoice==2) {
			customer_choice_change();
		}
		
	}
	public static void make_changes() {
		System.out.print("Do you wish to proceed or make changes in your choice ?");
		System.out.print("1.Proceed with payment 	2.Make changes in List");
	}
	
	public static void choice_of_customer() {
		System.out.println("Please enter your name: ");
		inp.nextLine();
		custname[custcount][0]=inp.nextLine();
		
		System.out.print("Enter number of food items you wish to buy: ");
		n=inp.nextInt();
		int coun=getCount();
		if(n>coun) {
			System.out.print("Number of items selected is greater than the number of items available!!  Order Declined!");
			choice_of_customer();
		}
		for(j=0;j<n;j++) {
			System.out.println("Please enter serial number of food item of your choice: ");
			inp.nextLine();
			a[j][0]=inp.nextInt();
			System.out.print("Enter the quantity of the food item of serial number: " + a[j][0]);
			a[j][1]=inp.nextInt();
			Node tempq1=head;
			while(tempq1!=null){
				for(j=0;j<n;j++) {
					while(tempq1!=null) {
					if(tempq1.quantity<a[j][1]	&& tempq1.serial==a[j][0]){
						System.out.println("Quantity chosen is more than available!");
						choice_of_customer();
					}
					if(tempq1.serial==a[j][0] && tempq1.quantity>=a[j][1])
						tempq1.quantity-=a[j][1];
					tempq1=tempq1.next;
				}
				if(j==n)
					break;
				}
		}
			
		}
	}
	
	public static void proceed() throws IOException, InterruptedException {
		System.out.println("The total bill for your purchase is: ");
		Node temps=head;
		System.out.println(" ");
		System.out.println("Serial Number 		Food Name		 Quantity		 Price");
		while(temps!=null){
			for(j=0;j<n;j++) {
				while(temps!=null) {
				if(temps.serial==a[j][0]){
					System.out.println("    "+ a[j][0] +"   		    "    + temps.name + "	                   " + a[j][1] + " \t\t 	 " + a[j][1]*temps.price);
					totalbill=totalbill+(a[j][1]*temps.price);
				}
				temps=temps.next;
			}
			if(j==n)
				break;
			}
		}
		proceed_for_payment();
		
		}
	
	
	public static void proceed_for_payment() throws IOException, InterruptedException {
		System.out.println("Amount payable: " + totalbill);
		
		System.out.println("1.Proceed to Pay  	2.Cancel Order");
		j=inp.nextInt();
		if(j==1) {
			System.out.println("You have successfully ordered your food items! ");
			totalbillstr=Float.toString(totalbill);
			custname[custcount][1]=totalbillstr;
			custID[custcount]=generate_custId();
			enqueue(custID[custcount]);
			System.out.println("Please collect your order after five seconds!! \n");
			System.out.println("Your ID :" + custID[custcount] + "\n");
			k=custcount;
			for(j=0;j<k+1;j++) {
				timer();
				dequeue();
				k--;
			}
			custcount++;
			System.out.println("Thank You");
			totalbill=0;
		}
		else if(j==2) {
			System.out.println("Are you sure to cancel your order? ");
			System.out.println("1.Yes 	2.No");
			inp.nextLine();
			int pay=inp.nextInt();
			if(pay==1) {
				System.out.println("Thank you for the purchase!!");
				custID[custcount]=generate_custId();
				System.out.println("Please collect your order after five seconds!! \n");
				System.out.println("Your ID :" + custID[custcount] + "\n");
				k=custcount;
				for(j=0;j<k+1;j++) {
					timer();
					dequeue();
					System.out.println(custID[custcount]);
					k--;
				}
				custcount++;
				totalbill=0;
			}
			else if(pay==2) {
				System.out.println("Your Order has been successfully cancelled!");
				custcount--;
				choice();
			}
			else {
				System.out.println("Invalid Choice!!");
				proceed_for_payment();
			}
		}
	}
	
	public static int generate_custId() {
		Random rand = new Random();
		return rand.nextInt(1000); 
	}
	
	
	@SuppressWarnings("null")
	public static void customer_choice_change() throws IOException, InterruptedException {
		System.out.println("The previous choices of yours: ");
		for(j=0;j<n;j++) 
			System.out.println(a[j][0] + "   " + a[j][1]);
		System.out.println("Enter the serial number of the food you wish to change: ");
		int k=inp.nextInt();
		for(j=0;j<n;j++) {
			if(a[j][0]==k) {
				System.out.print("Enter the new serial number: ");
				a[j][0]=inp.nextInt();
				System.out.print("Enter the quantity of the food: ");
				a[j][1]=inp.nextInt();
				Node tempq=head;
				while(tempq!=null){
					for(j=0;j<n;j++) {
						while(tempq!=null) {
						if(tempq.quantity<a[j][1]){
							System.out.println("The chosen item's quantity is more than available!!  Order Declined!");
							choice_of_customer();
						}
						}
						tempq=tempq.next;
					}
					if(j==n)
						break;
					}
			}
			else {
				System.out.println("Invalid Serial Number");
				return;
			}
		}
		proceed_for_payment();
		
	}
	public static void choice() throws IOException, InterruptedException {
			System.out.println("1.Login to admin panel	2.Customer	3.Exit");
			int ch=inp.nextInt();
			if(ch==1) {
				System.out.println("If you are redirected here soon after entering credentials...");
				System.out.println("Then those credentials are not matching!!!     Try Again! ");
				get_admin_confirmation();
				choice();
			}
			else if(ch==2) {
				customer();
				choice();
			}
			else if(ch==3) {
				System.out.println("Thank You for using our System !");
				write_payments();
			}
				else {
				System.out.println(" Invalid Choice");
				choice();
			}
	}
	
	
	public static void write_payments() throws IOException {
		System.out.println("\n"+"Your Order details has been successfully recorded in the database." + "\n");
		System.out.println( "This is only for the purpose of administrator." + "\n");
		File myObj = new File("Payments.txt");
		if (myObj.createNewFile()) {
	        System.out.println("Writing to the File: " + myObj.getName() + "\n");
	      } 
		else {
	        try {
				  FileWriter myWriter = new FileWriter("Payments.txt",true);
			      for(l=0; l<custcount;l++) {
			    	  DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");  
			    	  LocalDateTime now = LocalDateTime.now();   
			    	  myWriter.write("\n" + dtf.format(now) + " 			    " +  custname[l][0] + "                  \t\t" + custname[l][1] + "\n");
			      }
			      myWriter.close();
			}
			catch(IOException e) {
				System.out.println("An error occurred.");
			    e.printStackTrace();
			}
	      }
		
	}
	
	public static void get_admin_confirmation() throws IOException {
		
		File inputFile = new File("AdminData.txt");
		Scanner in = new Scanner(inputFile);
		inp.nextLine();
		System.out.println("Please enter your user name: ");
		String userNameInput = inp.nextLine().toLowerCase();
		System.out.println("Enter the correct password (case sensitive): " + "\n");
		String passwordInput = inp.nextLine();
    
    try {
           while (in.hasNextLine())
           {
        	 
             String s = in.nextLine();  
             String[] sArray = s.split(",");
             
             if (userNameInput.equals(sArray[0])   && passwordInput.equals(sArray[1]))
             {
            	 System.out.println("\n"+ " Login Successfull!!" + "\n");
            	 System.out.println("Welcome      " + userNameInput);
 				 admin();
             }
             else
               System.out.println("  ");
             
           }
           
           in.close();
           
       } catch (FileNotFoundException e) {
    	   System.out.println("File Not Found!!");
		    e.printStackTrace();
       }
	}
	
	
	public static void timer() throws IOException, InterruptedException {
	        new FiveSecondsTimer(10,custID[custcount]);
	}

	
/*	public static void completeTask()throws IOException {
        try {
            //assuming it takes 20 secs to complete the task
            Thread.sleep(10000);
            System.out.println(custID[custcount]);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
	}*/
	
	public static void main(String [] args) throws IOException, InterruptedException { 
		
		addfood(1,"Chicken Lollipop",50,200);
		addfood(3,"Grilled Sandwich",45,105);
		addfood(2,"Pizza",60,150);
		addfood(4,"Burger",33,120);
		addfood(6,"Egg Roll",52,80);
		addfood(5,"Paneer Crispy",30,75);

		System.out.println("Please enter your choice: ");
		choice();
}
}
